﻿using Microsoft.AspNetCore.Mvc;
using demoexam.Data;
using demoexam.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace demoexam.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ProductController : Controller
    {
        private readonly TradeDbContext _context;

        public ProductController(TradeDbContext context)
        {
            _context = context;
        }

        // GET: Product/Create


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(
      [Bind("ProductArticleNumber,ProductName,ProductDescription,ProductCategory,ProductManufacturer,ProductCost,ProductDiscountAmount,ProductQuantityInStock,ProductStatus")]
    Product product,
      IFormFile productImage)
        {
            if (ModelState.IsValid)
            {
                // Обработка изображения
                if (productImage != null && productImage.Length > 0)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        await productImage.CopyToAsync(memoryStream);
                        product.ProductPhoto = memoryStream.ToArray();
                    }
                }
                else
                {
                    // Убедитесь, что файл существует
                    var defaultImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "default-product.png");
                    if (System.IO.File.Exists(defaultImagePath))
                    {
                        product.ProductPhoto = await System.IO.File.ReadAllBytesAsync(defaultImagePath);
                    }
                }

                try
                {
                    _context.Add(product);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Товар успешно добавлен";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", "Ошибка при сохранении: " + ex.Message);
                }
            }

            // Логируем ошибки валидации
            foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
            {
                Console.WriteLine(error.ErrorMessage);
            }

            return View(product);
        }

        // GET: Product/Index
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.ToListAsync();
            return View(products);
        }
    }
}
