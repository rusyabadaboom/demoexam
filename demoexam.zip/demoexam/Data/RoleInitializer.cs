﻿using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;

namespace demoexam.Data
{
    public static class RoleInitializer
    {
        public static async Task InitializeAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            string[] roleNames = { "Admin", "Manager", "Client" };

            foreach (var roleName in roleNames)
            {
                if (await roleManager.RoleExistsAsync(roleName))
                {
                    continue;
                }
                await roleManager.CreateAsync(new IdentityRole(roleName));
            }
        }
    }
}