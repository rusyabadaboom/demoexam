﻿using demoexam.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace demoexam.Data
{
    public class TradeDbContext : IdentityDbContext<ApplicationUser, IdentityRole, string>
    {
        public TradeDbContext(DbContextOptions<TradeDbContext> options)
            : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Важно вызвать базовый метод!

            // Ваши кастомные конфигурации, если есть
            modelBuilder.Entity<OrderProduct>()
                .HasKey(op => new { op.OrderID, op.ProductArticleNumber });
        }

        // Добавьте DbSet для ваших сущностей
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderProduct> OrderProducts { get; set; }
    }
}