﻿namespace demoexam.Models
    
{
    public class Order
    {
        public int OrderID { get; set; }
        public string OrderStatus { get; set; }
        public DateTime OrderDeliveryDate { get; set; }
        public string OrderPickupPoint { get; set; }
        public ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
